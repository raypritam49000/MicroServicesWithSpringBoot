package com.melardev.spring.rxmscrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RxMsCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(RxMsCrudApplication.class, args);
	}

}
