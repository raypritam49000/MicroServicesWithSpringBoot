package com.melardev.spring.mail.services;

import com.melardev.spring.mail.models.Todo;

public interface IReporterService {
    void report(Todo todo);
}
