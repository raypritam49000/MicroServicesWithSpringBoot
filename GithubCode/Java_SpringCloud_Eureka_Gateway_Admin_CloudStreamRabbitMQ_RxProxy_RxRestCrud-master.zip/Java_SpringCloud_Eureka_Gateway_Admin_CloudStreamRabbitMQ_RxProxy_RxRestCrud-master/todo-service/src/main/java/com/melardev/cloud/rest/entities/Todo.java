package com.melardev.cloud.rest.entities;

import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "todos")
public class Todo extends TimeStampedDocument {

    private String title;
    private String description;

    private boolean completed;

    public Todo() {
    }

    public Todo(String title, String description) {
        this(title, description, false);
    }

    public Todo(String title, String description, boolean completed) {
        this.title = title;
        this.description = description;
        this.completed = completed;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }


    @Override
    public String toString() {
        return String.format("Todo{Title: %s, Description: %s, Completed: %s, CreatedAt: %s, UpdatedAt: %s}",
                title, description, completed, createdAt, updatedAt);
    }
}